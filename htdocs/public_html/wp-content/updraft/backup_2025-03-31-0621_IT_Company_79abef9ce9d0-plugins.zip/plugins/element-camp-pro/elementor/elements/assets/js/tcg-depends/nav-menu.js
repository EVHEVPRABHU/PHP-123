
(function($) {
    "use strict";
    $('.navbar-nav').smartmenus();

})(jQuery);


// (function($ul, complete) {
//  $ul.fadeIn(250, complete); 
// })(jQuery);