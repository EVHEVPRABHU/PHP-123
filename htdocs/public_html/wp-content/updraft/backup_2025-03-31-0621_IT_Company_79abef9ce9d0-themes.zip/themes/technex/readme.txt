=== Technex ===
Contributors: themescamp
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Version: 1.0.2
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html    
Text Domain: technex 
Domain Path: /lang   
Tags: one-column, two-columns, right-sidebar,custom-colors,featured-images, app, software, IT solution

== Description ==
Technex is a Technology & Software WordPress Theme

== Installation ==
1. Go to Themes > Add New, search for "Technex" and then click "Install".
2. After installaion is done click on "Activate".
3. Enjoy!
